
public class PrimitiveLiterals {

	public static void main(String[] args) {
		
		//Declaring bytes, shorts and ints
		byte b = 1;
		short sh = 1;
		int i = 1;

		// Declaring longs, floats and doubles
		long l = 1L;
		float f = 1f;
		double d = 1d;
		
		System.out.print(
				"Byte: " + b + "\n" +
				"Short: " + sh + "\n" +
				"Int: " + i + "\n" +
				"Long: " + l + "\n" +
				"Float: " + f + "\n" +
				"Double: " + d );
	}

}
