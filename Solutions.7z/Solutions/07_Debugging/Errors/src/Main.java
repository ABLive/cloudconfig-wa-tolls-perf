
public class Main {

	public static void main(String[] args) {
		String s = null;
		System.out.println(s);
		
		String[] strings = {"Welcome!"};
		System.out.println(strings[1]);
		
	}

}
