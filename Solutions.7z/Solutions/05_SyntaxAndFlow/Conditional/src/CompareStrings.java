
public class CompareStrings {

	public static void main(String[] args) {
		String month = "February";
		
		if (month.equals("February")) {
			System.out.println("It's the second month!");
		}
	}

}
