
public enum Month {
	JANUARY, FEBRUARY, MARCH;
}
