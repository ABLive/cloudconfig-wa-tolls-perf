
public class Main {

	public static void main(String[] args) {

		byte  b  = 5;
		System.out.println("The value of b is " + b);

		short s  = 32500;
	    System.out.println("The value of s is " + s);

	    int i = 7243234;
	    System.out.println("The value of i is " + i);

//	    double d = 3.14159;
//	    System.out.println("The value of d is " + d);
//		
//	    String welcome = "Hello World";
//		System.out.println("The value of welcome is " + welcome);
//	
//		CustomClass c = new CustomClass();
//		System.out.println("The value of the class var is " + c.customVariable);
	}

}
